package Utils;

public enum DriverType {
	CHROME, FIREFOX, IE, EDGE;
}
