package SortByProductNamePageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class SortByProductNamePageObject {
	
	// Locators 
	final static String SORTBYBUTTON_ID = "sorter";
	
	// WebElement identification
	@FindBy(how = How.ID, using= SORTBYBUTTON_ID )
	public static WebElement sortBy;
	
	// Method 
	public void setOption (){
		
		Select list = new Select(sortBy);
		list.selectByValue("name");
	}

	
	

}
