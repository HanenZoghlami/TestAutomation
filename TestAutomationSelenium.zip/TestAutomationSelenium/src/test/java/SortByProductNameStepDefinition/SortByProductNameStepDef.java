package SortByProductNameStepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import SortByProductNamePageObject.SortByProductNamePageObject;
import Utils.Setup;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SortByProductNameStepDef {

	public WebDriver driver;
	
	// instantiate PageObject class
	
	private SortByProductNamePageObject sortByProductNamePageObject= new SortByProductNamePageObject();
	
	// constructor
	
	public SortByProductNameStepDef() {
		driver = Setup.driver;
		PageFactory.initElements(driver, SortByProductNamePageObject.class);
		
		
	}
	
	@Given("^i have product Displayed in the first page in the website$")
	public void iHaveProductDisplayedInTheFirstPageInTheWebsite() throws Throwable {
	
	driver.get("https://highlifeshop.com/speedbird-cafe");
		
	}

	@When("^I click on “sort by” and i choose Product Name$")
	public void iClickOnSortByAndIChooseProductName() throws Throwable {
		sortByProductNamePageObject.setOption();	
	    
	}

	
	

	@Then("^i should successfully display list of product name in ascending alphabetic order$")
	public void i_should_successfully_display_list_of_product_name_in_ascending_alphabetic_order() throws Throwable {
	   
	}


}
